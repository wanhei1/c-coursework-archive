#include<stdio.h>
main()
{int a,i,j;
 for(a=1;a<=9;a++)
 printf("%4d",a);
 printf("\n------------------------------------\n");
 for (i=1;i<=9;i++)
 {for(j=1;j<=i;j++)
  {
  printf("%4d",i*j);
  if(i==j)
  putchar('\n');
  }
 } 
 return 0;
} 
