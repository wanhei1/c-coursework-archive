#include<stdio.h>
main()
{int a,b,c;
 scanf("%d,%d\n",&a,b);
 if(a>b)
    c=a;
 else
    c=b;
 printf("%d",c);
}
