#include<stdio.h>
#include<stdlib.h> 
main()
{int a;
 p:scanf("%d",&a);
 if(a<=60) goto p;
 printf("%d",a); 
}
