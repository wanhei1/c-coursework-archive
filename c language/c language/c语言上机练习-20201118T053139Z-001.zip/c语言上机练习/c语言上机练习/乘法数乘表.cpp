#include<stdio.h>
main()
{int i,j,n;
 for(n=1;n<=9;n++)
 printf("%4d",n);
 printf("\n------------------------------------\n");
 for(i=1;i<=9;i++)
 for(j=1;j<=i;j++)
  printf(i==j?"%4d\n":"%4d",i*j);
}
