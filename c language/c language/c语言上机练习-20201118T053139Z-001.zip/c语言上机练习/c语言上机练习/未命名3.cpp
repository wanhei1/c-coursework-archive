#include<stdio.h>
main()
{int n=1,s=0,x;
 scanf("%d",&x);
 p:for(;n<=x;)
   {s+=n;
    n++;
   }
 printf("S=%d",s);  
}
