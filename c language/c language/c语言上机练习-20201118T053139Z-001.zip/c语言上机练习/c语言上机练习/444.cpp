#include<stdio.h>
int main()
{scanf("%d,%d",&a,&b);
 if(a>b)
   {printf("abcdefg\n");
   }
  printf("bbbbbbb\n"); 
} 
