#include<stdio.h>
main()
{int a=5,b=7;
 char c[]="COMPUTER"; 
 printf("a=%3d,b=%3d,a-b=%+d,a/d=%d%%",a,b,a-b,100*a/b);
 printf() 
}
 
