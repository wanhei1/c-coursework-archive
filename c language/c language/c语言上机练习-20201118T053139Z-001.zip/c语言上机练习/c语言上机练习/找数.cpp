#include<stdio.h>
main()
{int n;
 long a;
 printf("Please input number\n");
 scanf("%ld",&a);
 for(n=999;n>=100;n--)
 {if(n%3==0)
  {printf("%d",n);
  break;
  }
 }
}
