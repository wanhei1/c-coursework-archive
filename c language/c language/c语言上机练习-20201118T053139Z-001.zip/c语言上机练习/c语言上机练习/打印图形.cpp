#include<stdio.h>
 main()
{int n;
 scanf("%d",&n);
 printf("*      *\n");
 printf("**    **\n");
 printf("***  ***\n");
 printf("********\n");
} 
