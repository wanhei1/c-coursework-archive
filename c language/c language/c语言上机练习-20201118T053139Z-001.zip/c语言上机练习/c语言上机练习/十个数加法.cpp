#include<stdio.h>
main()
{int count,num,total;
 count=0;total=0;
 while(count<10)
 {count++;
  printf("Please enter the No.%d\n",count);
  scanf("%d",&num);
  total+=num;
  printf("num%d=%d\n",count,total);
  printf("\n\n");
 }
printf("The total of the ten counts is %d",total);
return 0;
 
} 
