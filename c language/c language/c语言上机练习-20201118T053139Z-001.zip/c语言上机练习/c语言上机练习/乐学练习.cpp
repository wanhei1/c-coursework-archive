#include<stdio.h>
main()
{
  float x,y=3;
  x=5/9.0;
  printf("%f",x);
} 
