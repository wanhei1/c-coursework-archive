#include<stdio.h>
main()
{int i=5;
 float a=3.5,a1;
 double b=123456789.12345678;
 char c='A';
 printf("i=%d,a=%f,b=%f,c=%c\n",i,a,b,c);
 a1=i,i=a,a=b,c=i;
 printf("i=%d,a=%f,a1=%f,c=%c\n",i,a,a1,c);
}
 
