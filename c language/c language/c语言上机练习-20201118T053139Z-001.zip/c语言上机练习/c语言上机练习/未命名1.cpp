#include<stdio.h> 
main()
{int i,j,n;
 scanf("%d",&n);
 for(i=1;i<=2*n-1;i++)
 {if(i<=n)
    {for(j=1;j<=n+i-1;j++)
     if(j<=n-i)
     printf(" ");
     else
     if(j<n+i-1)
     printf("*");
     printf("*\n");}
 else
    for(j=1;j<=3*n-i+1;j++)
     if(j<=i-n)
     printf(" ");
     else
     if(j<3*n-i+1)
     printf("*");
     printf("*\n");
 }
} 
