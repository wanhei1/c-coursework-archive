#include<stdio.h>
main()
{float a,b;
 char op;
 scanf("%1f%1c%1f",&a,&op,&b);
 switch (op)
 {case '+':
   printf("%f+%f=%f\n",a,b,a+b);break;
  case '-':
   printf("%f-%f=%f\n",a,b,a-b);break;
  case '*':
   printf("%f*%f=%f\n",a,b,a*b);break;
  case '/':
   if(b!=0)
     printf("%f/%f=%.2f\n",a,b,a/b);
   else
     printf("Division by zero\n");break;
  default:
   printf("Unknown operater.\n"); 
 }
} 
