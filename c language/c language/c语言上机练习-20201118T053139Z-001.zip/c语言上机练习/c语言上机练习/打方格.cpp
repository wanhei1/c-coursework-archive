#include<stdio.h>
main()
{int m,n;
 for(m=1;m<=4;m++)
 {for(n=1;n<=m+2;n++)
  printf("* ");
  printf("\n");
 }
} 
